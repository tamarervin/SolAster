# SDO HMI RVs

Pipeline to independently derive 'sun-as-a-star' radial velocity variations.
